/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.8.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSlider>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QWidget *verticalLayoutWidget;
    QVBoxLayout *verticalLayout;
    QWidget *layoutWidget;
    QGridLayout *gridLayout;
    QPushButton *rectButton;
    QPushButton *ellipseButton;
    QPushButton *brushButton;
    QWidget *layoutWidget1;
    QGridLayout *gridLayout_2;
    QSlider *rSlider;
    QLabel *rLabel;
    QFrame *colorPreview;
    QSlider *gSlider;
    QLabel *gLabel;
    QSlider *bSlider;
    QLabel *bLabel;
    QLabel *fr;
    QWidget *widget;
    QGridLayout *gridLayout_3;
    QPushButton *loadButton;
    QPushButton *saveButton;
    QPushButton *clearButton;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName("MainWindow");
        MainWindow->resize(800, 600);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName("centralwidget");
        verticalLayoutWidget = new QWidget(centralwidget);
        verticalLayoutWidget->setObjectName("verticalLayoutWidget");
        verticalLayoutWidget->setGeometry(QRect(20, 140, 741, 381));
        verticalLayout = new QVBoxLayout(verticalLayoutWidget);
        verticalLayout->setObjectName("verticalLayout");
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        layoutWidget = new QWidget(centralwidget);
        layoutWidget->setObjectName("layoutWidget");
        layoutWidget->setGeometry(QRect(13, 13, 122, 103));
        gridLayout = new QGridLayout(layoutWidget);
        gridLayout->setObjectName("gridLayout");
        gridLayout->setContentsMargins(0, 0, 0, 0);
        rectButton = new QPushButton(layoutWidget);
        rectButton->setObjectName("rectButton");

        gridLayout->addWidget(rectButton, 0, 0, 1, 1);

        ellipseButton = new QPushButton(layoutWidget);
        ellipseButton->setObjectName("ellipseButton");

        gridLayout->addWidget(ellipseButton, 1, 0, 1, 1);

        brushButton = new QPushButton(layoutWidget);
        brushButton->setObjectName("brushButton");

        gridLayout->addWidget(brushButton, 2, 0, 1, 1);

        layoutWidget1 = new QWidget(centralwidget);
        layoutWidget1->setObjectName("layoutWidget1");
        layoutWidget1->setGeometry(QRect(143, 14, 366, 102));
        gridLayout_2 = new QGridLayout(layoutWidget1);
        gridLayout_2->setObjectName("gridLayout_2");
        gridLayout_2->setContentsMargins(0, 0, 0, 0);
        rSlider = new QSlider(layoutWidget1);
        rSlider->setObjectName("rSlider");
        rSlider->setMinimumSize(QSize(200, 0));
        rSlider->setMaximum(255);
        rSlider->setOrientation(Qt::Orientation::Horizontal);

        gridLayout_2->addWidget(rSlider, 0, 0, 1, 1);

        rLabel = new QLabel(layoutWidget1);
        rLabel->setObjectName("rLabel");
        rLabel->setMinimumSize(QSize(50, 0));

        gridLayout_2->addWidget(rLabel, 0, 1, 1, 1);

        colorPreview = new QFrame(layoutWidget1);
        colorPreview->setObjectName("colorPreview");
        QSizePolicy sizePolicy(QSizePolicy::Policy::Fixed, QSizePolicy::Policy::Fixed);
        sizePolicy.setHorizontalStretch(100);
        sizePolicy.setVerticalStretch(100);
        sizePolicy.setHeightForWidth(colorPreview->sizePolicy().hasHeightForWidth());
        colorPreview->setSizePolicy(sizePolicy);
        colorPreview->setMinimumSize(QSize(100, 100));
        colorPreview->setFrameShape(QFrame::Shape::StyledPanel);
        colorPreview->setFrameShadow(QFrame::Shadow::Raised);

        gridLayout_2->addWidget(colorPreview, 0, 2, 3, 1);

        gSlider = new QSlider(layoutWidget1);
        gSlider->setObjectName("gSlider");
        gSlider->setMinimumSize(QSize(200, 0));
        gSlider->setMaximum(255);
        gSlider->setOrientation(Qt::Orientation::Horizontal);

        gridLayout_2->addWidget(gSlider, 1, 0, 1, 1);

        gLabel = new QLabel(layoutWidget1);
        gLabel->setObjectName("gLabel");
        gLabel->setMinimumSize(QSize(50, 0));

        gridLayout_2->addWidget(gLabel, 1, 1, 1, 1);

        bSlider = new QSlider(layoutWidget1);
        bSlider->setObjectName("bSlider");
        bSlider->setMinimumSize(QSize(200, 0));
        bSlider->setMaximum(255);
        bSlider->setOrientation(Qt::Orientation::Horizontal);

        gridLayout_2->addWidget(bSlider, 2, 0, 1, 1);

        bLabel = new QLabel(layoutWidget1);
        bLabel->setObjectName("bLabel");
        bLabel->setMinimumSize(QSize(50, 0));

        gridLayout_2->addWidget(bLabel, 2, 1, 1, 1);

        fr = new QLabel(centralwidget);
        fr->setObjectName("fr");
        fr->setGeometry(QRect(20, 140, 741, 381));
        fr->setFrameShape(QFrame::Shape::Box);
        widget = new QWidget(centralwidget);
        widget->setObjectName("widget");
        widget->setGeometry(QRect(540, 10, 191, 111));
        gridLayout_3 = new QGridLayout(widget);
        gridLayout_3->setObjectName("gridLayout_3");
        gridLayout_3->setContentsMargins(0, 0, 0, 0);
        loadButton = new QPushButton(widget);
        loadButton->setObjectName("loadButton");

        gridLayout_3->addWidget(loadButton, 1, 0, 1, 1);

        saveButton = new QPushButton(widget);
        saveButton->setObjectName("saveButton");

        gridLayout_3->addWidget(saveButton, 0, 0, 1, 1);

        clearButton = new QPushButton(widget);
        clearButton->setObjectName("clearButton");

        gridLayout_3->addWidget(clearButton, 2, 0, 1, 1);

        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName("menubar");
        menubar->setGeometry(QRect(0, 0, 800, 25));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName("statusbar");
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        rectButton->setText(QCoreApplication::translate("MainWindow", "\320\237\321\200\321\217\320\274\320\276\321\203\320\263\320\276\320\273\321\214\320\275\320\270\320\272", nullptr));
        ellipseButton->setText(QCoreApplication::translate("MainWindow", "\320\255\320\273\320\273\320\270\320\277\321\201", nullptr));
        brushButton->setText(QCoreApplication::translate("MainWindow", "\320\232\320\270\321\201\321\202\321\214", nullptr));
        rLabel->setText(QCoreApplication::translate("MainWindow", "rLabel", nullptr));
        gLabel->setText(QCoreApplication::translate("MainWindow", "gLabel", nullptr));
        bLabel->setText(QCoreApplication::translate("MainWindow", "bLabel", nullptr));
        fr->setText(QString());
        loadButton->setText(QCoreApplication::translate("MainWindow", "\320\227\320\260\320\263\321\200\321\203\320\267\320\270\321\202\321\214", nullptr));
        saveButton->setText(QCoreApplication::translate("MainWindow", "\320\241\320\276\321\205\321\200\320\260\320\275\320\270\321\202\321\214", nullptr));
        clearButton->setText(QCoreApplication::translate("MainWindow", "\320\236\321\207\320\270\321\201\321\202\320\270\321\202\321\214", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
