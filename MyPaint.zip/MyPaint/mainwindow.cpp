#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent), ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    ui->fr->setAttribute(Qt::WA_TransparentForMouseEvents);

    holst = new Holst(this);
    ui->verticalLayout->addWidget(holst);

    updateCurrentColor();

    connect(ui->rectButton, &QPushButton::clicked, this, &MainWindow::selectRectangle);
    connect(ui->ellipseButton, &QPushButton::clicked, this, &MainWindow::selectEllipse);
    connect(ui->brushButton, &QPushButton::clicked, this, &MainWindow::selectBrush);
    connect(ui->rSlider, &QSlider::valueChanged, this, &MainWindow::setRed);
    connect(ui->gSlider, &QSlider::valueChanged, this, &MainWindow::setGreen);
    connect(ui->bSlider, &QSlider::valueChanged, this, &MainWindow::setBlue);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::selectRectangle()
{ holst->setShapeType("Rectangle"); }

void MainWindow::selectEllipse()
{ holst->setShapeType("Ellipse"); }

void MainWindow::selectBrush()
{ holst->setShapeType("Brush"); }

void MainWindow::setRed(int)
{ updateCurrentColor(); }

void MainWindow::setGreen(int)
{ updateCurrentColor(); }

void MainWindow::setBlue(int)
{ updateCurrentColor(); }

void MainWindow::updateCurrentColor()
{
    int r = ui->rSlider->value();
    int g = ui->gSlider->value();
    int b = ui->bSlider->value();

    ui->rLabel->setText(QString::number(r));
    ui->gLabel->setText(QString::number(g));
    ui->bLabel->setText(QString::number(b));

    QColor color(r, g, b);
    holst->setColor(color);

    ui->colorPreview->setStyleSheet(QString
                                    ("background-color: rgb(%1, %2, %3);")
                                        .arg(r).arg(g).arg(b));
}

void MainWindow::on_saveButton_clicked()
{
    QString fileName = QFileDialog::getSaveFileName(this, "Сохранить файл", "", "Shape Files (*.dat)");
    if (fileName.isEmpty())
        return;

    QFile file(fileName);
    if (!file.open(QIODevice::WriteOnly))
    {
        QMessageBox::warning(this, "Ошибка", "Не удалось открыть файл для записи.");
        return;
    }

    QDataStream out(&file);
    const QVector<Shape> &shapes = holst->getShapes();
    out << shapes.size();

    for (const Shape &shape : shapes)
        shape.save(out);
}

void MainWindow::on_loadButton_clicked()
{
    QString fileName = QFileDialog::getOpenFileName(this, "Открыть файл", "", "Shape Files (*.dat)");
    if (fileName.isEmpty())
        return;

    QFile file(fileName);
    if (!file.open(QIODevice::ReadOnly))
    {
        QMessageBox::warning(this, "Ошибка", "Не удалось открыть файл для чтения.");
        return;
    }

    QDataStream in(&file);
    int count;
    in >> count;

    QVector<Shape> loadedShapes;
    for (int i = 0; i < count; ++i)
    {
        Shape shape;
        shape.load(in);
        loadedShapes.append(shape);
    }

    holst->setShapes(loadedShapes);
    holst->update();
}

void MainWindow::on_clearButton_clicked() { holst->setShapes({}); }
