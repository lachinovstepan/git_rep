#include "holst.h"

Holst::Holst(QWidget *parent) : QWidget(parent)
{ setAttribute(Qt::WA_StaticContents); }

void Holst::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    painter.setRenderHint(QPainter::Antialiasing);

    for (Shape &shape : shapes)
        shape.draw(painter);

    if (drawing)
        tempShape.draw(painter);
}

void Holst::mousePressEvent(QMouseEvent *event) {
    drawing = true;

    if (currentShapeType == "Brush")
    {
        tempShape.type = "Brush";
        tempShape.color = currentColor;
        tempShape.points.clear();
        tempShape.points.append(event->pos());
    }
    else
    {
        tempShape.type = currentShapeType;
        tempShape.color = currentColor;
        tempShape.rect.setTopLeft(event->pos());
        tempShape.rect.setBottomRight(event->pos());
    }

    update();
}

void Holst::mouseMoveEvent(QMouseEvent *event) {
    if (!drawing) return;

    if (currentShapeType == "Brush")
    { tempShape.points.append(event->pos()); }
    else
    { tempShape.rect.setBottomRight(event->pos()); }

    update();
}

void Holst::mouseReleaseEvent(QMouseEvent *event) {
    if (!drawing) return;

    drawing = false;

    if (currentShapeType == "Brush")
    {
        shapes.append(tempShape);
        tempShape.points.clear();
    }
    else
    {
        tempShape.rect.setBottomRight(event->pos());
        shapes.append(tempShape);
    }

    update();
}

void Holst::undo()
{
    if (!shapes.isEmpty())
    {
        shapes.removeLast();
        update();
    }
}
