#include <QString>
#include <QVector>
#include <QDataStream>
#include <QColor>
#include <QPainter>
#include <QRect>

struct Shape
{
    QString type;
    QRect rect;
    QColor color;
    QVector<QPoint> points;

    Shape() {}

    Shape(const QString &type, const QRect &rect, const QColor &color)
        : type(type), rect(rect), color(color) {}

    Shape(const QString &type, const QVector<QPoint> &points, const QColor &color)
        : type(type), color(color), points(points) {}

    void draw(QPainter &painter) const
    {
        if (type == "Rectangle")
        {
            painter.setBrush(color);
            painter.setPen(Qt::NoPen);
            painter.drawRect(rect);
        }
        else if (type == "Ellipse")
        {
            painter.setBrush(color);
            painter.setPen(Qt::NoPen);
            painter.drawEllipse(rect);
        }
        else if (type == "Brush")
        {
            if (points.size() < 2) return;
            painter.setPen(QPen(color, 3, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin));
            for (int i = 1; i < points.size(); ++i)
                painter.drawLine(points[i - 1], points[i]);
        }
    }

    void save(QDataStream &out) const
    { out << type << rect << color << points; }

    void load(QDataStream &in)
    { in >> type >> rect >> color >> points; }
};
