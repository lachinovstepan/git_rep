#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include "holst.h"
#include <QFile>
#include <QFileDialog>
#include <QMainWindow>
#include <QMessageBox>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void selectRectangle();
    void selectEllipse();
    void selectBrush();
    void setRed(int);
    void setGreen(int);
    void setBlue(int);
    void on_saveButton_clicked();
    void on_loadButton_clicked();
    void on_clearButton_clicked();

private:
    Ui::MainWindow *ui;
    Holst *holst;

    void updateCurrentColor();
};

#endif // MAINWINDOW_H
