#ifndef HOLST_H
#define HOLST_H

#include "shape.h"
#include <QWidget>
#include <QMouseEvent>

class Holst : public QWidget
{
    Q_OBJECT

public:
    Holst(QWidget *parent = nullptr);

    void setShapeType(const QString &type) { currentShapeType = type; }
    void setColor(const QColor &color) { currentColor = color; }
    void setShapes(const QVector<Shape> &newShapes)
    {
        shapes = newShapes;
        update();
    }
    const QVector<Shape> &getShapes() const { return shapes; }

public slots:
    void undo();

protected:
    void paintEvent(QPaintEvent *event) override;
    void mousePressEvent(QMouseEvent *event) override;
    void mouseMoveEvent(QMouseEvent *event) override;
    void mouseReleaseEvent(QMouseEvent *event) override;

private:
    QVector<Shape> shapes;
    Shape tempShape;
    QString currentShapeType = "Brush";
    QColor currentColor = Qt::blue;
    bool drawing = false;
};


#endif // HOLST_H
